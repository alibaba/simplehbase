package com.alipay.simplehbase.convertor;

import java.lang.reflect.Field;

import com.alipay.simplehbase.client.ColumnConvertor;
import com.alipay.simplehbase.exception.SimpleHbaseException;

/**
 * ColumnConvertor�ĹǼ��ࡣ
 * <pre>
 * ����ColumnConvertor��ʵ����Ӧ�ü̳д��ࡣ
 * </pre>
 * 
 * @author xinzhi 
 * @version $Id: AbstractColumnConvertor.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public abstract class AbstractColumnConvertor implements ColumnConvertor {

    @Override
    public byte[] toBytes(Field field, Object obj) {
        Object value = null;
        try {
            value = field.get(obj);
        } catch (Exception e) {
            throw new SimpleHbaseException("field.get exception. obj=" + obj + " field=" + field, e);
        }

        if (value == null) {
            return null;
        }

        return fieldValueToBytes(field, value);
    }

}
