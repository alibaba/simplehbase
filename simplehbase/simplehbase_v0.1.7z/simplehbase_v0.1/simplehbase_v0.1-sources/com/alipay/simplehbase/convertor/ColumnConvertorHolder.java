package com.alipay.simplehbase.convertor;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.alipay.simplehbase.client.ColumnConvertor;
import com.alipay.simplehbase.exception.SimpleHbaseException;

/**
 * ColumnConvertorʵ����Holder�ࡣ
 * 
 * @author xinzhi 
 * @version $Id: ColumnConvertorHolder.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public class ColumnConvertorHolder {

    /**
     * ColumnConvertor��Class -> ColumnConvertor��ʵ����
     * */
    private static ConcurrentMap<Class<? extends ColumnConvertor>, ColumnConvertor> convertorCache = new ConcurrentHashMap<Class<? extends ColumnConvertor>, ColumnConvertor>();

    /**
     * ��ColumnConvertor��Class�õ�ColumnConvertor��ʵ����
     * 
     * @param type ColumnConvertor��Class��
     * @return ColumnConvertor��ʵ����
     * */
    public static ColumnConvertor findConvertor(Class<? extends ColumnConvertor> type) {

        if (convertorCache.get(type) == null) {
            try {
                convertorCache.putIfAbsent(type, type.newInstance());
            } catch (Exception e) {
                throw new SimpleHbaseException(e);
            }
        }
        return convertorCache.get(type);
    }
}
