package com.alipay.simplehbase.client;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;

import com.alipay.simplehbase.client.util.ClientUtil;
import com.alipay.simplehbase.exception.SimpleHbaseException;

/**
 * SimpleHbaseClient��ʵ�֡�
 * 
 * @author xinzhi 
 * @version $Id: SimpleHbaseClientImpl.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public class SimpleHbaseClientImpl implements SimpleHbaseClient {

    @Override
    public <T> T findObject(RowKey rowKey, Class<? extends T> type) {
        ClientUtil.checkRowKey(rowKey);
        ClientUtil.checkNull(type);

        Get get = new Get(rowKey.toBytes());

        HTableInterface htableInterface = HTablePoolHolder.getHTablePool(rowKey.getTableName());
        try {
            Result result = htableInterface.get(get);
            return convert(result, type);
        } catch (Exception e) {
            throw new SimpleHbaseException("findObject. rowkey=" + rowKey + " type=" + type, e);
        } finally {
            ClientUtil.close(htableInterface);
        }
    }

    @Override
    public <T> List<T> findObjectList(RowKey startRowKey, RowKey endRowKey, Class<? extends T> type) {
        ClientUtil.checkRowKey(startRowKey);
        ClientUtil.checkRowKey(endRowKey);
        ClientUtil.checkNull(type);
        ClientUtil.checkSameTableName(startRowKey, endRowKey);

        Scan scan = new Scan();
        scan.setStartRow(startRowKey.toBytes());
        scan.setStopRow(endRowKey.toBytes());
        //TODO allen batch��
        HTableInterface htableInterface = HTablePoolHolder
            .getHTablePool(startRowKey.getTableName());

        List<T> resultList = new LinkedList<T>();
        try {
            ResultScanner resultScanner = htableInterface.getScanner(scan);
            Result result = null;
            while ((result = resultScanner.next()) != null) {
                resultList.add(convert(result, type));
            }
        } catch (IOException e) {
            throw new SimpleHbaseException("findObjectList. startRowKey=" + startRowKey
                                           + " endRowKey=" + endRowKey + " type=" + type, e);
        } finally {
            ClientUtil.close(htableInterface);
        }

        return resultList;
    }

    @Override
    public <T> void putObject(RowKey rowKey, T t) {
        ClientUtil.checkRowKey(rowKey);
        ClientUtil.checkNull(t);

        Put put = new Put(rowKey.toBytes());
        TypeInfo typeInfo = TypeInfoHolder.findTypeInfo(t.getClass());
        for (ColumnInfo columnInfo : typeInfo.getColumnInfos()) {
            byte[] value = columnInfo.convertor.toBytes(columnInfo.field, t);
            put.add(columnInfo.familyBytes, columnInfo.qualifierBytes, value);
        }

        HTableInterface htableInterface = HTablePoolHolder.getHTablePool(rowKey.getTableName());
        try {
            htableInterface.put(put);
        } catch (IOException e) {
            throw new SimpleHbaseException("putObject. rowkey=" + rowKey + " t=" + t, e);
        } finally {
            ClientUtil.close(htableInterface);
        }
    }

    @Override
    public <T> boolean insertObject(RowKey rowKey, T t) {
        ClientUtil.checkRowKey(rowKey);
        ClientUtil.checkNull(t);

        TypeInfo typeInfo = TypeInfoHolder.findTypeInfo(t.getClass());
        ClientUtil.checkVersioned(typeInfo);

        Put put = new Put(rowKey.toBytes());
        for (ColumnInfo columnInfo : typeInfo.getColumnInfos()) {
            byte[] value = columnInfo.convertor.toBytes(columnInfo.field, t);
            put.add(columnInfo.familyBytes, columnInfo.qualifierBytes, value);
        }

        HTableInterface htableInterface = HTablePoolHolder.getHTablePool(rowKey.getTableName());
        boolean result = false;
        ColumnInfo versionedColumnInfo = typeInfo.getVersionedColumnInfo();
        try {
            result = htableInterface.checkAndPut(rowKey.toBytes(), versionedColumnInfo.familyBytes,
                versionedColumnInfo.qualifierBytes, null, put);
        } catch (IOException e) {
            throw new SimpleHbaseException("insertObject. rowkey=" + rowKey + " t=" + t, e);
        } finally {
            ClientUtil.close(htableInterface);
        }
        return result;
    }

    @Override
    public <T> boolean updateObject(RowKey rowKey, T oldT, T newT) {
        ClientUtil.checkRowKey(rowKey);
        ClientUtil.checkNull(oldT);
        ClientUtil.checkNull(newT);
        ClientUtil.checkSameType(oldT, newT);

        TypeInfo typeInfo = TypeInfoHolder.findTypeInfo(newT.getClass());
        ClientUtil.checkVersioned(typeInfo);

        Put put = new Put(rowKey.toBytes());
        try {
            boolean needUpdate = false;
            for (ColumnInfo columnInfo : typeInfo.getColumnInfos()) {
                Object oldValue = columnInfo.field.get(oldT);
                Object newValue = columnInfo.field.get(newT);
                if (newValue == null && oldValue == null) {
                    continue;
                } else if (newValue == null || oldValue == null || !newValue.equals(oldValue)) {
                    byte[] value = columnInfo.convertor.toBytes(columnInfo.field, newT);
                    put.add(columnInfo.familyBytes, columnInfo.qualifierBytes, value);
                    needUpdate = true;
                } else {
                    continue;
                }
            }
            if (!needUpdate) {
                return true;
            }
        } catch (Exception e) {
            throw new SimpleHbaseException("updateObject. rowKey=" + rowKey + " oldT=" + oldT
                                           + " newT=" + newT, e);
        }

        ColumnInfo versionedColumnInfo = typeInfo.getVersionedColumnInfo();
        byte[] oldValueOfVersion = versionedColumnInfo.convertor.toBytes(versionedColumnInfo.field,
            oldT);

        HTableInterface htableInterface = HTablePoolHolder.getHTablePool(rowKey.getTableName());
        boolean result = false;
        try {
            result = htableInterface.checkAndPut(rowKey.toBytes(), versionedColumnInfo.familyBytes,
                versionedColumnInfo.qualifierBytes, oldValueOfVersion, put);
        } catch (IOException e) {
            throw new SimpleHbaseException("updateObject. rowKey=" + rowKey + " oldT=" + oldT
                                           + " newT=" + newT, e);
        } finally {
            ClientUtil.close(htableInterface);
        }

        return result;

    }

    @Override
    public <T> boolean updateObjectWithVersion(RowKey rowKey, T t, Object oldVersion) {
        ClientUtil.checkRowKey(rowKey);
        ClientUtil.checkNull(t);
        //not check oldVersion,oldVersion can be null��

        TypeInfo typeInfo = TypeInfoHolder.findTypeInfo(t.getClass());
        ClientUtil.checkVersioned(typeInfo);

        Put put = new Put(rowKey.toBytes());
        for (ColumnInfo columnInfo : typeInfo.getColumnInfos()) {
            byte[] value = columnInfo.convertor.toBytes(columnInfo.field, t);
            put.add(columnInfo.familyBytes, columnInfo.qualifierBytes, value);
        }

        ColumnInfo versionedColumnInfo = typeInfo.getVersionedColumnInfo();
        byte[] oldValueOfVersion = versionedColumnInfo.convertor.fieldValueToBytes(
            versionedColumnInfo.field, oldVersion);

        HTableInterface htableInterface = HTablePoolHolder.getHTablePool(rowKey.getTableName());
        boolean result = false;
        try {
            result = htableInterface.checkAndPut(rowKey.toBytes(), versionedColumnInfo.familyBytes,
                versionedColumnInfo.qualifierBytes, oldValueOfVersion, put);
        } catch (IOException e) {
            throw new SimpleHbaseException("updateObjectWithVersion. rowKey=" + rowKey + " t=" + t
                                           + " oldVersion=" + oldVersion, e);
        } finally {
            ClientUtil.close(htableInterface);
        }

        return result;
    }

    @Override
    public void deleteObject(RowKey rowKey) {
        ClientUtil.checkRowKey(rowKey);

        HTableInterface htableInterface = HTablePoolHolder.getHTablePool(rowKey.getTableName());
        Delete delete = new Delete(rowKey.toBytes());

        try {
            htableInterface.delete(delete);
        } catch (IOException e) {
            throw new SimpleHbaseException("deleteObject. rowkey=" + rowKey, e);
        } finally {
            ClientUtil.close(htableInterface);
        }
    }

    /**
     * ת��hbase���ΪPOJO��
     * 
     * @param result result��
     * @param type POJO type��
     * @return POJO��
     * */
    private <T> T convert(Result result, Class<? extends T> type) {

        if (result.isEmpty()) {
            return null;
        }

        try {
            T t = type.newInstance();
            TypeInfo typeInfo = TypeInfoHolder.findTypeInfo(type);

            for (ColumnInfo columnInfo : typeInfo.getColumnInfos()) {

                byte[] hbaseColumnValue = result.getValue(columnInfo.familyBytes,
                    columnInfo.qualifierBytes);

                Object value = columnInfo.convertor.toObject(columnInfo.field, hbaseColumnValue);

                if (value != null) {
                    columnInfo.field.set(t, value);
                }
            }

            return t;
        } catch (Exception e) {
            throw new SimpleHbaseException("convert result exception. result=" + result + " type="
                                           + type, e);
        }
    }

}
