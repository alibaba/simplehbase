package com.alipay.simplehbase.client;

import java.lang.reflect.Field;

import org.apache.hadoop.hbase.util.Bytes;

import com.alipay.simplehbase.convertor.ColumnConvertorHolder;
import com.alipay.simplehbase.exception.SimpleHbaseException;

/**
 * POJO��field��Hbase����ӳ����Ϣ��
 * 
 * @author xinzhi 
 * @version $Id: ColumnInfo.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public class ColumnInfo {

    /**
     * ��POJO��field������ColumnInfo��
     * 
     * @param type POJO��class type��
     * @param field POJO��field��
     * @return ��������ColumnInfo��
     * */
    public static ColumnInfo parse(Class<?> type, Field field) {
        String defaultFamily = null;
        Class<? extends ColumnConvertor> defaultConvertor = null;
        HBaseTable hbaseTable = type.getAnnotation(HBaseTable.class);
        if (hbaseTable != null) {
            defaultFamily = hbaseTable.defaultFamily();
            defaultConvertor = hbaseTable.defaultConvertor();
        }

        HBaseColumn hbaseColumn = field.getAnnotation(HBaseColumn.class);
        if (hbaseColumn == null) {
            return null;
        }

        String family = hbaseColumn.family();
        String qualifier = hbaseColumn.qualifier();
        Class<? extends ColumnConvertor> convertor = hbaseColumn.convertor();

        if (family == null || family.length() == 0) {
            family = defaultFamily;
        }
        if (convertor == ColumnConvertor.class) {
            convertor = defaultConvertor;
        }

        if (family == null || family.length() == 0) {
            throw new SimpleHbaseException("family is null or empty. type=" + type + " field="
                                           + field);
        }

        if (qualifier == null || qualifier.length() == 0) {
            throw new SimpleHbaseException("qualifier is null or empty. type=" + type + " field="
                                           + field);
        }

        ColumnInfo columnInfo = new ColumnInfo();
        columnInfo.type = type;
        columnInfo.field = field;
        columnInfo.family = family;
        columnInfo.familyBytes = Bytes.toBytes(family);
        columnInfo.qualifier = qualifier;
        columnInfo.qualifierBytes = Bytes.toBytes(qualifier);
        columnInfo.convertor = ColumnConvertorHolder.findConvertor(convertor);

        return columnInfo;
    }

    /** POJO��class type�� */
    Class<?>        type;
    /** POJO��field�� */
    Field           field;
    /** hbase��family�� */
    String          family;
    /** hbase��family�� */
    byte[]          familyBytes;
    /** hbase��qualifier�� */
    String          qualifier;
    /** hbase��qualifier�� */
    byte[]          qualifierBytes;
    /** ���ж�Ӧ��ColumnConvertor�� */
    ColumnConvertor convertor;

    private ColumnInfo() {
    }

    @Override
    public String toString() {
        return "type=" + type + " field=" + field + " family=" + family + " qualifier=" + qualifier
               + " convertor=" + convertor;
    }
}