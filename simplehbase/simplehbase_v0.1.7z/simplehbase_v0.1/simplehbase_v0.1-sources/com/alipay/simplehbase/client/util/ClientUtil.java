package com.alipay.simplehbase.client.util;

import java.io.IOException;

import org.apache.hadoop.hbase.client.HTableInterface;

import com.alipay.simplehbase.client.RowKey;
import com.alipay.simplehbase.client.TypeInfo;
import com.alipay.simplehbase.exception.SimpleHbaseException;

/**
 * Client Util��
 * 
 * @author xinzhi 
 * @version $Id: ClientUtil.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public class ClientUtil {

    /**
     * Check object is null.
     * 
     * @param obj obj.
     * */
    public static void checkNull(Object obj) {
        if (obj == null) {
            throw new SimpleHbaseException("obj is null.");
        }
    }

    /**
     * ���rowKey.
     * <pre>
     * rowKey��Ϊnull��
     * rowKey��tableName��Ϊnull��
     * rowKey��toBytes��Ϊnull��
     * </pre>
     * 
     * @param rowKey rowKey��
     * */
    public static void checkRowKey(RowKey rowKey) {
        if (rowKey == null) {
            throw new SimpleHbaseException("rowkey is null.");
        }
        if (rowKey.getTableName() == null || rowKey.getTableName().length() == 0) {
            throw new SimpleHbaseException("rowkey has no table name. rowKey = " + rowKey);
        }
        if (rowKey.toBytes() == null || rowKey.toBytes().length == 0) {
            throw new SimpleHbaseException("rowkey bytes is null or empty. rowKey = " + rowKey);
        }
    }

    /**
     * �ر�HTableInterface��
     * 
     * @param htableInterface htableInterface��
     * */
    public static void close(HTableInterface htableInterface) {
        if (htableInterface == null) {
            return;
        }

        try {
            htableInterface.close();
        } catch (IOException e) {
            throw new SimpleHbaseException("close htableInterface exception.", e);
        }
    }

    /**
     * ���typeInfo�Ƿ��Ǵ��汾�ŵ�typeInfo��
     * 
     * @param typeInfo typeInfo��
     * */
    public static void checkVersioned(TypeInfo typeInfo) {
        checkNull(typeInfo);
        if (!typeInfo.isVersionedType()) {
            throw new SimpleHbaseException("not a versioned type. typeInfo = " + typeInfo.getType());
        }
    }

    /**
     * ���2����������ͬ��class��
     * 
     * @param obj ��1������
     * @param other ��2������
     * */
    public static void checkSameType(Object obj, Object other) {
        checkNull(obj);
        checkNull(other);
        if (obj.getClass() != other.getClass()) {
            throw new SimpleHbaseException("not same type. obj = " + obj + " other = " + other);
        }
    }

    /**
     * ���2��rowKey����ͬ��tablename��
     * 
     * @param rowKey ��1��rowKey��
     * @param other ��2��rowKey��
     * */
    public static void checkSameTableName(RowKey rowKey, RowKey other) {
        checkRowKey(rowKey);
        checkRowKey(other);
        String tableName = rowKey.getTableName();
        String otherTableName = other.getTableName();
        if (!tableName.equals(otherTableName)) {
            throw new SimpleHbaseException("not same table name. rowKey = " + rowKey + " other = "
                                           + other);
        }
    }

    private ClientUtil() {
    }
}
