package com.alipay.simplehbase.client;

import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.HTablePool;
import org.apache.log4j.Logger;

import com.alipay.simplehbase.config.ConfigConstants;
import com.alipay.simplehbase.exception.SimpleHbaseException;

/**
 * HTablePool��Holder��
 * 
 * @author xinzhi 
 * @version $Id: HTablePoolHolder.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public class HTablePoolHolder {

    /** log. */
    private static Logger     log = Logger.getLogger(HTablePoolHolder.class);

    /**
     * HTablePool.
     * */
    private static HTablePool htablePool;

    /**
     * �õ�ָ��������HTableInterface��
     * 
     * @param tableName ������
     * @return HTableInterface��
     * */
    public static HTableInterface getHTablePool(String tableName) {

        if (tableName == null) {
            throw new SimpleHbaseException("tableName is null.");
        }
        return htablePool.getTable(tableName);
    }

    /**
     * ��ʼ����
     * 
     * @param hbaseConfig hbase��config��
     * @param simpleHbaseConfig simplehbase��config��
     * */
    public static void init(Map<String, String> hbaseConfig, Map<String, String> simpleHbaseConfig) {
        if (hbaseConfig == null) {
            throw new SimpleHbaseException("hbaseConfig is null.");
        }
        if (simpleHbaseConfig == null) {
            throw new SimpleHbaseException("simpleHbaseConfig is null.");
        }

        log.info("hbaseConfig=" + hbaseConfig);
        log.info("simpleHbaseConfig=" + simpleHbaseConfig);

        int hbasePoolSize = parseInt(simpleHbaseConfig, ConfigConstants.HTABLE_POOL_SIZE);
        if (hbasePoolSize < 1) {
            throw new SimpleHbaseException("hbasePoolSize=" + hbasePoolSize);
        }

        Configuration ressultHbaseConfig = HBaseConfiguration.create();

        for (Map.Entry<String, String> entry : hbaseConfig.entrySet()) {
            ressultHbaseConfig.set(entry.getKey(), entry.getValue());
        }

        htablePool = new HTablePool(ressultHbaseConfig, hbasePoolSize);
    }

    /**
     * ����config�е�key��Ӧ��value��������������-1��
     * 
     * @param config config��
     * @param key key��
     * @return config�е�key��Ӧ��value��������������-1��
     * */
    private static int parseInt(Map<String, String> config, String key) {
        try {
            String vaule = config.get(key);
            return Integer.parseInt(vaule);
        } catch (Exception e) {
            return -1;
        }
    }
}
