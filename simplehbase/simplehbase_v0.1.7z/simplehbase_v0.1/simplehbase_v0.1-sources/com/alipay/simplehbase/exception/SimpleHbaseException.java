package com.alipay.simplehbase.exception;

/**
 * SimpleHbase��ͨ���쳣��
 * <pre>
 * ����simplehbase��ܵ��쳣��Ӧ�ü̳д��ࡣ
 * </pre>
 * 
 * @author xinzhi 
 * @version $Id: SimpleHbaseException.java 2013-09-11 ����11:27:31 xinzhi $
 * */
public class SimpleHbaseException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public SimpleHbaseException(String message) {
        super(message);
    }

    public SimpleHbaseException(String message, Throwable cause) {
        super(message, cause);
    }

    public SimpleHbaseException(Throwable cause) {
        super(cause);
    }
}
