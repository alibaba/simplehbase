package com.alipay.simplehbase.test;

public class MyRecordConstants {
	final public static String TableName = "MyRecord";
	final public static String ColumnFamilyName = "MyRecordFamily";
}
