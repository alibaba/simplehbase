package com.alipay.simplehbase.test;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTablePool;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.alipay.simplehbase.client.SimpleHbaseClient;
import com.alipay.simplehbase.client.SimpleHbaseClientFactory;
import com.alipay.simplehbase.config.ConfigConstants;
import com.alipay.simplehbase.config.SimpleHBaseConfig;

public class TestMyRecord {

	protected static HBaseAdmin hbaseAdmin;
	protected static HTablePool pool;
	private static SimpleHbaseClient simpleHbaseClient;

	@BeforeClass
	public static void beforeClass() throws Exception {
		hbaseAdmin = CommonConfig.getHBaseAdmin();
		deleteTable();
		createTable();

		initSimpleHbase();
		initSimpleHbaseClient();
	}

	@AfterClass
	public static void afterClass() throws Exception {
		deleteTable();
	}

	@Before
	public void before() {
		deleteRecords();
	}

	@After
	public void after() {
		deleteRecords();
	}

	private void deleteRecords() {
		MyRecord[] myRecords = new MyRecord[8];
		for (int i = 0; i < myRecords.length; i++) {
			MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen" + i);
			simpleHbaseClient.deleteObject(myRecordRowKey);
		}
	}

	private static void initSimpleHbase() {

		// hbase stand alone mode, no need to pass hbase config here.

		// simplehbase config.
		Map<String, String> configMap = new HashMap<String, String>();
		configMap.put(ConfigConstants.HTABLE_POOL_SIZE, "5");

		SimpleHBaseConfig simpleHBaseConfig = new SimpleHBaseConfig();
		simpleHBaseConfig.setSimpleHbaseConfig(configMap);

		// init simplehbase.
		simpleHBaseConfig.init();
	}

	private static void initSimpleHbaseClient() {
		simpleHbaseClient = SimpleHbaseClientFactory.getSimpleHbaseClient();
	}

	private static void createTable() throws Exception {
		// create new table.
		HTableDescriptor tableDescriptor = new HTableDescriptor(
				MyRecordConstants.TableName);

		tableDescriptor.addFamily(new HColumnDescriptor(
				MyRecordConstants.ColumnFamilyName));

		hbaseAdmin.createTable(tableDescriptor);
	}

	private static void deleteTable() throws Exception {
		// delete table if table exist.
		if (hbaseAdmin.tableExists(MyRecordConstants.TableName)) {
			// disable table before delete it.
			hbaseAdmin.disableTable(MyRecordConstants.TableName);
			hbaseAdmin.deleteTable(MyRecordConstants.TableName);
		}
	}

	@Test
	public void testPutAndFind() {

		MyRecord myRecord = new MyRecord();
		myRecord.setId(0);
		myRecord.setName("allen1");
		myRecord.setDate(new Date());
		myRecord.setVersion(0L);

		MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen1");

		simpleHbaseClient.putObject(myRecordRowKey, myRecord);
		MyRecord myRecord2 = simpleHbaseClient.findObject(myRecordRowKey,
				MyRecord.class);
		Assert.assertTrue(myRecord.equals(myRecord2));
	}

	@Test
	public void testDelete() {
		MyRecord myRecord = new MyRecord();
		myRecord.setId(0);
		myRecord.setName("allen1");
		myRecord.setDate(new Date());
		myRecord.setVersion(0L);

		MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen1");

		simpleHbaseClient.putObject(myRecordRowKey, myRecord);
		simpleHbaseClient.deleteObject(myRecordRowKey);
		MyRecord myRecord2 = simpleHbaseClient.findObject(myRecordRowKey,
				MyRecord.class);
		Assert.assertNull(myRecord2);
	}

	@Test
	public void testFindObjectList() {

		MyRecord[] myRecords = new MyRecord[8];
		for (int i = 0; i < myRecords.length; i++) {
			MyRecord myRecord = new MyRecord();
			myRecord.setId(i);
			myRecord.setName("allen" + i);
			myRecord.setDate(new Date());
			myRecord.setVersion(0L);
			myRecords[i] = myRecord;
			MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen" + i);
			simpleHbaseClient.putObject(myRecordRowKey, myRecord);
		}

		MyRecordRowKey startRowKey = new MyRecordRowKey("key_allen" + 0);
		MyRecordRowKey endRowKey = new MyRecordRowKey("key_allen" + 8);
		List<MyRecord> list = simpleHbaseClient.findObjectList(startRowKey,
				endRowKey, MyRecord.class);

		Assert.assertTrue(list.size() == myRecords.length);
	}

	@Test
	public void testInsert() {
		MyRecord myRecord = new MyRecord();
		myRecord.setId(0);
		myRecord.setName("allen1");
		myRecord.setDate(new Date());
		myRecord.setVersion(0L);

		MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen1");

		Assert.assertTrue(simpleHbaseClient.insertObject(myRecordRowKey,
				myRecord));
		Assert.assertFalse(simpleHbaseClient.insertObject(myRecordRowKey,
				myRecord));
	}

	@Test
	public void testUpdate() {
		MyRecord myRecord = new MyRecord();
		myRecord.setId(0);
		myRecord.setName("allen1");
		myRecord.setDate(new Date());
		myRecord.setVersion(0L);
		MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen1");

		simpleHbaseClient.insertObject(myRecordRowKey, myRecord);
		MyRecord myRecordFromHbase = simpleHbaseClient.findObject(
				myRecordRowKey, MyRecord.class);
		// change version.
		myRecordFromHbase.setVersion(10L);
		Assert.assertFalse(simpleHbaseClient.updateObject(myRecordRowKey,
				myRecordFromHbase, myRecord));

		// change version.
		myRecordFromHbase.setVersion(0L);
		// update version.
		myRecord.setVersion(1L);
		Assert.assertTrue(simpleHbaseClient.updateObject(myRecordRowKey,
				myRecordFromHbase, myRecord));

	}

	@Test
	public void testUpdateObjectWithVersion() {
		MyRecord myRecord = new MyRecord();
		myRecord.setId(0);
		myRecord.setName("allen1");
		myRecord.setDate(new Date());
		myRecord.setVersion(0L);
		MyRecordRowKey myRecordRowKey = new MyRecordRowKey("key_allen1");

		simpleHbaseClient.insertObject(myRecordRowKey, myRecord);

		// update with wrong version.
		Assert.assertFalse(simpleHbaseClient.updateObjectWithVersion(
				myRecordRowKey, myRecord, new Long(10L)));

		// update version.
		myRecord.setVersion(1L);
		Assert.assertTrue(simpleHbaseClient.updateObjectWithVersion(
				myRecordRowKey, myRecord, new Long(0L)));

	}
}
