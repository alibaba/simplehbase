package com.alipay.simplehbase.test;

import org.apache.hadoop.hbase.util.Bytes;

import com.alipay.simplehbase.client.RowKey;

public class MyRecordRowKey implements RowKey {

	private String row;

	public MyRecordRowKey(String row) {
		this.row = row;
	}

	@Override
	public byte[] toBytes() {
		return Bytes.toBytes(row);
	}

	@Override
	public String getTableName() {
		return MyRecordConstants.TableName;
	}

	@Override
	public String toString() {
		return "MyRecordRowKey [row=" + row + "]";
	}
}
